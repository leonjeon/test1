package board.model.vo;

import java.util.Comparator;

public class DescBoardTitle implements Comparator {

	
	
	//6> 글제목순 내림차순정렬 처리용 클래스
	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
