package board.model.vo;

import java.util.Comparator;

public class AscBoardDate implements Comparator{

	
	
	//4> 작성날짜순 오름차순정렬 처리용 클래스
	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
