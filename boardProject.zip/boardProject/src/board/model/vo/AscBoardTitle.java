package board.model.vo;

import java.util.Comparator;

public class AscBoardTitle implements Comparator{

	
	
	
	//5> 글제목순 오름차순정렬 처리용 클래스
	@Override
	public int compare(Object o1, Object o2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
