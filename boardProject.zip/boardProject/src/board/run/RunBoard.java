package board.run;

import board.view.BoardMenu;

public class RunBoard {

	public static void main(String[] args) {
		//테스트용 클래스
		//1. BoardMenu 클래스 객체 생성함
		//2. BoardMenu 클래스의 mainMenu() 메소드 실행함
		BoardMenu bm = new BoardMenu();
		
		bm.mainMenu();
		
	}

}
